---
title: _Template.md
author: Gildong Hong (gildong@hong.com)  
date: 2018-01-30
---
[![Analytics](https://ga-beacon.appspot.com/UA-137501847-1/AurixRacer/docs/_Template.md)](https://github.com/realsosy/aurixracer)

# _Template for Infineon Racer

## 시작하는 질문



------



## Objectives

* ​



## References
* TC23x TC22x Family User's Manual v1.1 - Chap
* iLLD_TC23A Help / Modules/ 

**[Example Code]**

* MyIlldModule_TC23A -
* InfineonRacer_TC23A - 




------



## Example Description 

* ​



## Background 정보



## AURIX - related

* ​

## iLLD - related
* ​

### Module Configuration 

```c

```



### Interrupt Configuration 

```c

```



### Module Behavior 

```c

```



## 추가적인 설명



------



## 마치며...
